/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;

public class AddTheater {
    Statement stmt;

    public void AddTheater(String theaterID, String name, String location, 
        String nos, String sc, String phoneNumber) {
        try {
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate(
                "INSERT INTO theaters (theaterID, name, location, nos, sc, phoneNumber) VALUES('"
                        + theaterID + "', '" + name + "', '" + location + "', '" + nos + "', '"
                        + sc + "', '" + phoneNumber + "')"
            );
        System.out.println("Theater Record added Successfull");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
