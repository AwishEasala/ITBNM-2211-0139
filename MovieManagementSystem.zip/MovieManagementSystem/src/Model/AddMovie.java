/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;

public class AddMovie {
    Statement stmt;
    
    public void movies(String movieID, String movieName, String genre, 
        String director, String Date) 
    {
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate
            ("INSERT INTO movies (movieID, movieName, genre, director, Date) VALUES('"+ 
                    movieID +"', '"+ movieName +"', '"+ genre +"', '"+ director +"', '"+ Date +"')");
            System.out.println("Movie Record added Successfull");

        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
}
