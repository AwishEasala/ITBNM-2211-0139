/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class UpdateDeleteMovie {
         
    public static boolean updateMovie(String movieID, String movieName, String genre, 
        String director, String Date) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean success = false;

        try {
            conn = DBConnection.getConnection();
            
            String query = "UPDATE movies SET movieName=?, genre=?, director=?, date=? WHERE movieID=?";
            
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, movieName);
            pstmt.setString(2, genre);
            pstmt.setString(3, director);
            pstmt.setString(4, Date);
            pstmt.setString(5, movieID);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                success = true;
            }
        } finally {
            if (pstmt != null) {
                pstmt.close();
            }
        }
        
        return success;
    }
    
    public static boolean deleteMovie(String movieID) throws SQLException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean success = false;

        try {
            conn = DBConnection.getConnection();
            String query = "DELETE FROM movies WHERE movieID=?";

            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, movieID);
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                success = true;
            }
        } finally {
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        
        return success;
    }
    
}
