/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.UpdateDeleteMovie;
import Model.UpdateDeleteTheaters;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class MovieController {
    
public static void movies(String movieID, String movieName, String genre, 
        String director, String Date) {
    new Model.AddMovie().movies(movieID, movieName, genre, director, Date);
    JOptionPane.showMessageDialog(null, "New Record has been inserted", 
            "Successfull", JOptionPane.INFORMATION_MESSAGE);
    }

    public static boolean updateMovie(String movieID, String movieName, String genre, 
        String director, String Date) throws SQLException {
            boolean success = false;
            success = UpdateDeleteMovie.updateMovie(movieID, movieName, genre, director, Date);
            return success;
        }
    
    public static boolean deleteMovie(String movieID) throws SQLException {
        boolean success = false;
        success = UpdateDeleteMovie.deleteMovie(movieID);
        return success;
    }
    
}
