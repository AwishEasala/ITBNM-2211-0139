/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.UpdateDeleteTheaters;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class TheaterController {
    
    public static void Theater(String theaterID, String name, String location, 
        String nos, String sc, String phoneNumber) {
    new Model.AddTheater().AddTheater(theaterID, name, location, nos, sc, phoneNumber);
    JOptionPane.showMessageDialog(null, "New Record has been inserted", 
            "Successfull", JOptionPane.INFORMATION_MESSAGE);
    }    
    
    public static boolean updateTheater(String theaterID, String name, String location, 
        String nos, String sc, String phoneNumber) {
        boolean success = false;
        try {
            success = UpdateDeleteTheaters.updateTheater(theaterID, name, location, nos, sc, phoneNumber);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return success;
    }
    
    public static boolean deleteTheater(String theaterID) throws SQLException {
        boolean success = false;
        success = UpdateDeleteTheaters.deleteTheater(theaterID);
        return success;
    }
    
}  
